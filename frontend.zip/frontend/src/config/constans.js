export const URLBASE = 'http://localhost:5000'

export const ENDPOINT = {
  login: `${URLBASE}/login`,
  users: `${URLBASE}/usuarios`
}
